<html>
<head>
<title>Login Failed</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body id="body">
<div id="textFail">~~~~~ Login Failed ~~~~~</div>
<div id="return">
<input type="submit" value="Return Home" 
    onclick="window.location='auth.php';" />
</div>

<img id="getout" src="images/getout.jpg" alt="" border="2" cellpadding="2"/>
</body>
</html>